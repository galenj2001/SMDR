/* Program name and version information */

#ifndef _SMDR_VERSION_H_
#define _SMDR_VERSION_H_

#define SMDR_NAME       "SMDR (Standard Model in Dimensional Regularization)"
#define SMDR_VERSION    "1.01"

#endif
